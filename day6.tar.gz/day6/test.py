class Thread:
    def start(self):
        self.run()

    def run(self):
        pass
